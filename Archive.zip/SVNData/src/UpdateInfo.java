import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdateInfo {
	public static void main(String[] args) throws SQLException {
		String url = "jdbc:mysql://localhost:3306/StudentList";
		String user = "root";
		String password = "kranthi";
		Connection myConn = null;
		Statement myStmt = null;
		try {
			// 1. Get a connection to database
			myConn = DriverManager.getConnection(url, user, password);
			// 2. Create a statement
			myStmt = myConn.createStatement();
			// 3. Execute SQL query
			//String sql = "update SVN_COLLEGE_DATA set Birthyear='1990' where Admission_ID=10429";
			//int rowsAffected = myStmt.executeUpdate(sql);//first update
			
			String sql1 = "update SVN_COLLEGE_DATA set Birthyear='1991' where Admission_ID=10427";
			int rowsAffected = myStmt.executeUpdate(sql1);
			
			
			System.out.println("Rows affected: " + rowsAffected);
			System.out.println("Update complete.");
			
		} catch (Exception exc) {
			exc.printStackTrace();
		} finally {
			if (myStmt != null) {
				myStmt.close();
			}
			if (myConn != null) {
				myConn.close();
			}
		}
	}
}