import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentDetails {
	public static void main(String[] args) throws SQLException {
		String url = "jdbc:mysql://localhost:3306/StudentList";
		String user = "root";
		String password = "kranthi";
		Connection myConn = null;
		Statement myStmt = null;
		try {
			
			myConn = DriverManager.getConnection(url, user, password);
			
			myStmt = myConn.createStatement();
			
			/*String sql = "insert into SVN_COLLEGE_DATA " + " (Admission_ID, First_name, Last_name, Birthyear)"
					+ " values ('10425', 'Vineel', 'Ratna', '1985')";
			myStmt.executeUpdate(sql);*///first entry
			
			String sql1 = "insert into SVN_COLLEGE_DATA " + " (Admission_ID, First_name, Last_name, Birthyear)"
					+ " values ('10426', 'Kiran', 'Reddy', '1987')";
			String sql2 = "insert into SVN_COLLEGE_DATA " + " (Admission_ID, First_name, Last_name, Birthyear)"
					+ " values ('10427', 'Varun', 'Krishna', '1984')";
			String sql3 = "insert into SVN_COLLEGE_DATA " + " (Admission_ID, First_name, Last_name, Birthyear)"
					+ " values ('10428', 'Amar', 'Shastri', '1986')";
			String sql4 = "insert into SVN_COLLEGE_DATA " + " (Admission_ID, First_name, Last_name, Birthyear)"
					+ " values ('10429', 'Anand', 'Chowhan', '1987')";
			String sql5 = "insert into SVN_COLLEGE_DATA " + " (Admission_ID, First_name, Last_name, Birthyear)"
					+ " values ('10430', 'Vishnu', 'Raj', '1986')";
			myStmt.executeUpdate(sql1);
			myStmt.executeUpdate(sql2);
			myStmt.executeUpdate(sql3);
			myStmt.executeUpdate(sql4);
			myStmt.executeUpdate(sql5);
			
			System.out.println("Insert complete.");
			
		} catch (Exception exc) {
			exc.printStackTrace();
		} finally {
			if (myStmt != null) {
				myStmt.close();
			}
			if (myConn != null) {
				myConn.close();
			}
		}
	}
}